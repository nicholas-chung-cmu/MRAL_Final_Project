"""Estimation using Dead Reckoning, KF, and EKF for 16-362: Mobile Robot Algorithms Laboratory
"""

import numpy as np


class Estimator:
    """Estimator object containing various methods to estimate state of a differential
    drive robot.

    Attributes:
        r: (float) Radius of the wheels of the robot.
        L: (float) Distance between the two wheels.
        dt: (float) Timestep size.
    """

    def __init__(self, dt=0.04, radius=0.033, axle_length=0.16):
        self.r = radius
        self.L = axle_length
        self.dt = dt

    def dead_reckoning(self, x, u):
        """Estimate the next state using the previous state x and the control
        input u via Dead Reckoning.

        Args:
            x: (np.array for 3 floats) State at the previous timestep
            u: (np.array for 2 floats) Control input to the left (u[0]) and right (u[1]) wheels

        Returns:
            next_x: (np.array of 3 floats) State at the current timestep
        """
        # TODO: Assignment 2, Problem 2.1

        x_dot = np.matmul(np.array([[self.r / 2 * np.cos(x[2]), self.r / 2 * np.cos(x[2])], 
                                    [self.r / 2 * np.sin(x[2]), self.r / 2 * np.sin(x[2])], 
                                    [-self.r / self.L, self.r / self.L]]), u)

        next_x = x + x_dot * self.dt
        return next_x
        raise NotImplementedError

    def kalman_filter(self, x, P, u, y, Q, R):
        """Localization via Kalman Filtering.

        Estimate the next state and the associated uncertainty from the previous state x
        and uncertainty P, control input u, observation y, process noise covariance Q, and
        measurement noise covariance R. Note that in this case we are ignoring heading state (ψ).

        Args:
            x: (np.array for 2 floats) State at the previous timestep
            P: (np.array of floats, 2x2) Uncertainty in the state at the previous timestep
            u: (np.array for 2 floats) Control input to the left (u[0]) and right (u[1]) wheels
            y: (np.array for 2 floats) GPS observation of the position (x, y)
            Q: (np.array of floats, 2x2) Process model noise covariance matrix
            R: (np.array of floats, 2x2) Measurement model noise covariance matrix

        Returns:
            (next_x, next_P): Tuple(np.array of 2 floats, np.array of floats with shape 2x2)
                              Next state vector and covariance matrix
        """
        # TODO: Assignment 2, Problem 2.2

        # process model
        psi = np.pi / 4
        cpsi = np.cos(psi)
        spsi = np.sin(psi)
        A = np.identity(2)
        B = np.array([[self.dt * self.r / 2 * cpsi, self.dt * self.r / 2 * cpsi], 
                      [self.dt * self.r / 2 * spsi, self.dt * self.r / 2 * spsi]])
        next_x = np.matmul(A, x) + np.matmul(B, u)

        # measurement model
        C = np.identity(2)

        # uncertainty update
        next_P = np.matmul(np.matmul(A, P), A) + Q # assumed A' == A

        # Kalman gain
        K = np.matmul(np.matmul(next_P, C), np.linalg.inv((np.matmul(np.matmul(C, next_P), C) + R))) #assumed C' == C

        # correction
        next_x = next_x + np.matmul(K, (y - np.matmul(C, next_x)))
        next_P = np.matmul((np.identity(2) - np.matmul(K, C)), next_P)
        return next_x, next_P
        raise NotImplementedError

    def extended_kalman_filter(self, x, P, u, y, Q, R):
        """Localization via Extended Kalman Filtering.

        Estimate the next state and the associated uncertainty from the previous state x
        and uncertainty P, control input u, observation y, process noise covariance Q, and
        measurement noise covariance R. Note that in this case we are not ignoring heading state (ψ).

        Args:
            x: (np.array for 3 floats) State at the previous timestep
            P: (np.array of floats, 3x3) Uncertainty in the state at the previous timestep
            u: (np.array for 2 floats) Control input to the left (u[0]) and right (u[1]) wheels
            y: (np.array for 2 floats) GPS observation of the position (x, y)
            Q: (np.array of floats, 3x3) Process model noise covariance matrix
            R: (np.array of floats, 2x2) Measurement model noise covariance matrix

        Returns:
            (next_x, next_P): Tuple(np.array of 3 floats, np.array of floats with shape 3x3)
                              Next state vector and covariance matrix
        """
        # TODO: Assignment 2, Problem 2.3
        
        # process model
        psi = x[2]
        cpsi = np.cos(psi)
        spsi = np.sin(psi)
        dgdx = np.array([[0, 0, -self.r*spsi/2*(u[1] - u[0])], 
                         [0, 0,  self.r*cpsi/2*(u[1] - u[0])], 
                         [0, 0, 0]])
        A = dgdx

        x_dot = np.matmul(np.array([[self.r / 2 * np.cos(x[2]), self.r / 2 * np.cos(x[2])], 
                                    [self.r / 2 * np.sin(x[2]), self.r / 2 * np.sin(x[2])], 
                                    [-self.r / self.L, self.r / self.L]]), u)

        next_x = x + x_dot * self.dt
        

        # measurement model
        C = np.array([[1, 0, 0], [0, 1, 0]])

        # uncertainty update
        next_P = np.matmul(np.matmul(A, P), np.transpose(A)) + Q 

        # Kalman gain
        K = np.matmul(np.matmul(next_P, np.transpose(C)), np.linalg.inv((np.matmul(np.matmul(C, next_P), np.transpose(C)) + R))) 

        # correction
        next_x = next_x + np.matmul(K, (y - np.matmul(C, next_x)))
        next_P = np.matmul((np.identity(3) - np.matmul(K, C)), next_P)
        return next_x, next_P
        raise NotImplementedError
